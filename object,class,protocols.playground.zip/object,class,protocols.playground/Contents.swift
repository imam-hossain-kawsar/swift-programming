//: Playground - noun: a place where people can play

import UIKit

protocol GroceryItem {
    func cost() -> Float
    func description() -> String
}

struct Beef: GroceryItem {
    func description() -> String {
        return "\(name): \(weight): \(pricePerWeight)"
    }
    
    
    let name: String
    let weight: Float
    let pricePerWeight: Float
    func cost() -> Float {
        return weight * pricePerWeight
    }
}


struct Apple: GroceryItem {
    func description() -> String {
        return "\(name): \(price)"
    }
    

    let name: String
    let price: Float
    
    func cost() -> Float {
        return price
    }
}
struct Customer {
    let name: String
    let groceries: [GroceryItem]
}

struct GroceryStore {
    func printReceipt(customer: Customer) {
        var total: Float = 0
        print("Printing receipt for customer: \(customer.name)")
        customer.groceries.forEach { (item) in
            print(item.description())
            print(item.cost())
            
//            if let groceryItem = item as? GroceryItem {
//                print(groceryItem.description())
//                total += groceryItem.cost()
            
//            if let apple = item as? Apple {
//                print("\(apple.name): \(apple.price)")
//                total += apple.price
//            }else if let beef = item as? Beef {
//                print("\(beef.name): \(beef.weight * beef.pricePerWeight)")
//                total += beef.pricePerWeight * beef.weight
            }
//        }
//        print(total)
    }
        
    
}
let newYorkSteak = Beef(name: "newYorkSteak", weight: 2.3, pricePerWeight: 4.5)
let goldenApple = Apple(name: "golden Apple", price: 4.5)
let greenApple = Apple(name: "Green Apple", price: 1.99)
let bill = Customer(name: "Bill", groceries: [greenApple, goldenApple, newYorkSteak])
let safeway = GroceryStore()
safeway.printReceipt(customer: bill)

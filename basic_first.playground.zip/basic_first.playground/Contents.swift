//: Playground - noun: a place where people can play

import UIKit
//lession 1
/*var str = "Hello, playground. i am new to swift"
print(str)
var a = 1
var b = 1
a = 2
 
var constant = 2
constant = 4
print(a + b)
print(a - b)
print(a * b)
print(a / b)*/


//lession 2

//this lession shows how to use explicit data types like String,Int, Double, Float and Bool. Some examples are given below:
/*var x:Int = 3
var y:String = "hello viena"
var z:Double = 3.33
var xx:Float = 34.3
print(x)
print(y)
print(z)
print(xx)*/

// lession 3: if-else if- else
/*let conditional_variable1 = 10
let conditional_variable2 = 1
let conditional_variable3 = 3
if (conditional_variable1 < 4 || conditional_variable2 < 4) && conditional_variable3 != 3 {
    print("branch 1")
}
else if !(conditional_variable1 == 10 && conditional_variable2 == 1) {
    print("branch 2")
}
else if conditional_variable1 < 8 {
    print("branch 3")
}
else {
    print("noting was true")
}*/

// lession 4: switch statements
/*var somecharacter = "d"
switch somecharacter {
case "a":
    print("is an A")
case "b", "c":
    print("is an B or C")
default:
    print("some fallback")
}
//lession 5: for loops

let minValue = UInt8.min
let maxValue = UInt8.max
var sum = 0
for index in 1...100 {
    sum += index
}
print(sum)
let names = ["imam", "hossain", "kawsar", 6, 45.78, 5.7, true] as [Any]
for name in names {
    print("Hello \(name)")
    print(type(of: name))
}
let numberOfLegs = ["spiders": 8, "ant": 6, "cat": 4]
for (animalName, legCount) in numberOfLegs {
    print("\(animalName)s have \(legCount) legs")
}
let minutes = 60
for tickMark in 0..<minutes {
    print(tickMark)
}
let minuteInterval = 5
for tickMark in stride(from: 0, to: minutes, by: minuteInterval) {
    print(tickMark)
}
let hours = 12
let hourInterval = 3
for tickMark in stride(from: 3, through: hours, by: hourInterval) {
    print(tickMark)
}*/
/*let finalSquare = 25
var board = [Int](repeating: 0, count: finalSquare + 1)
board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
var square = 0
var diceRoll = 0
print(board)
while square < finalSquare {
    let randomDiceValue = Int(arc4random_uniform(6) + 1)
    print("this is random variable \(randomDiceValue)")
    diceRoll += randomDiceValue
    
    
    square += diceRoll
    if square < board.count {
        square += board[square]
    }
}
print("Game Over!!!!")*/
// lession 6: while loop + repeat while
// lession 7 + lession 8: Functions
/////////
/// HAVE TO STUDY MORE......
/////////
/*func addTwoNumbers(_ number:Int, _ number1:Int) -> Int{
    let a = number
    let b = number1
    let c = a + b
    
    return c
}

func subtractTwoNumbers(arg number:Int, and number1:Int) -> Int {
    let d = number1
    let a = number
    let e = a - d
    
    return e
}
let sum = addTwoNumbers(5, 4)
print(sum)
let sub = subtractTwoNumbers(arg:5, and: 3)
print(sub)*/

//lession 9: Class
/*class Blogpost {
    var title = ""
    var body = ""
    var author = ""
    var numberOfComments = 0
    
    func addComment() {
        numberOfComments += 1
    }
}
let mypost = Blogpost()
mypost.author = "imam hossain kawsar"
mypost.body = "Hello"
mypost.title = "Hello there!"
mypost.addComment()
mypost.numberOfComments
print(mypost.author)

let mySecondPost = Blogpost()
mySecondPost.author = "J K ROWLING"
mySecondPost.body = "HARRY POTTER"
mySecondPost.title = "deathly hallow"
mySecondPost.addComment()
print(mySecondPost.numberOfComments)*/

// lession 10: Inheritance

// experiment on ! and ?
// (!) This can be used for non nil value
// (?) This can be used for optional value
// let's check
//var john:String?
//john = "Is his name"
//print(john!)
/*
var john:String?
print(john!)*/
/*
var dict: [String:AnyObject] = Dictionary()
dict["name"] = "John" as AnyObject
var str: String = dict["name"]! as! String*/
var someoptionalString: String? = "optional"
var someoptionalString2: Optional<String> = "optional"

if someoptionalString != nil {
    if someoptionalString!.hasPrefix("opt") {
        print("has the prefix")
    }
}

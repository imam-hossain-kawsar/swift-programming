//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"
//print(str)
//
//func add(_ param:Int, _ param1:Int) -> Int{
//
//    return param + param1
//}
//add(34, 34)

//func BMICalculator(_ weight: Double, _ height: Double) -> String {
//    var BMIValue: Double = 0.0
//    BMIValue = (weight / (height * height))
//    if BMIValue > 25.0 {
//        return "Your BMIValue is \(BMIValue). You are overweight"
//    }
//    else if BMIValue >= 18.5 && BMIValue <= 25 {
//        return "Your BMIValue is \(BMIValue). You are normal weight"
//    }
//    else {
//        return "Your BMIValue is \(BMIValue). You are underweight"
//    }
//}
//var BMIStatus = BMICalculator(60, 1.5)
//print(BMIStatus)

func fibonacci(until: Int) {
    var first = 0
    var second = 1
    var temp = 0
    print(first)
    print(second)
    for number in 1...until {
        print(first + second)
        temp = first
        first = second
        second = temp + first
        
    }
}
fibonacci(until: 5)
